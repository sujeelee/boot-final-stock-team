package kh.st.boot.model.util;

public enum UserRole {
	ADMIN, USER
}
