package kh.st.boot.model.enums;

public enum SocialType {
    KAKAO, NAVER, GOOGLE
}
