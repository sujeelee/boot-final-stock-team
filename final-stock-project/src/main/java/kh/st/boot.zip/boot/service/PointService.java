package kh.st.boot.service;

public interface PointService {

    boolean usePoint(String string, Integer integer, String string2);
    
}
