package kh.st.boot.model.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class admOrderPageVO {
	
	private String od_id;
	private String od_name;
	private String mb_id;
	private int od_price;
	private int od_point;
	private String od_date;
	private String od_status;
	private String od_st_code;
	private String od_st_name;
	private int od_qty;
	private int od_st_price;
	private int od_percent_price;
}










