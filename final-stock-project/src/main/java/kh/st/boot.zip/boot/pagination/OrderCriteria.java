package kh.st.boot.pagination;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderCriteria extends Criteria{

    private String od_search = ""; 

}
