package kh.st.boot.service;

import kh.st.boot.model.vo.AdminVO;

public interface AdminService {
	

	AdminVO getAdminH();

	boolean admUpdate(AdminVO adminVO);



	


}