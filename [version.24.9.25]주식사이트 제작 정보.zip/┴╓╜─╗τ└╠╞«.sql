﻿CREATE TABLE `member` (
	`mb_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`mb_id`	varchar(255)	NULL,
	`mb_password`	varchar(255)	NULL,
	`mb_name`	varchar(50)	NULL,
	`mb_nick`	varchar(100)	NULL,
	`mb_hp`	varchar(100)	NULL,
	`mb_email`	varchar(255)	NULL,
	`mb_zip`	int(11)	NULL,
	`mb_addr`	varchar(255)	NULL,
	`mb_addr2`	varchar(255)	NULL,
	`mb_birth`	int(11)	NULL	COMMENT '양식 8 자리 숫자
00000000
ex) 19960908',
	`mb_level`	int(11)	NULL	COMMENT '1LV~7LV 일반회원
10LV 관리자 회원',
	`mb_datetime`	DATETIME	NULL,
	`mb_edit_date`	DATETIME	NULL,
	`mb_stop_date`	DATETIME	NULL,
	`mb_out_date`	DATETIME	NULL	COMMENT '회원 탈퇴시 탈퇴일 update
회원 정보의 경우 아이디 + 이름 빼고 삭제',
	`mb_cookie`	varchar(255)	NULL,
	`mb_cookie_limit`	varchar(255)	NULL,
	`mb_point`	int(11)	NULL,
	`mb_emailing`	tinyint(4)	NULL,
	`mb_account`	varchar(255)	NULL
);

CREATE TABLE `config` (
	`cf_title`	varchar(255)	NULL,
	`cf_info`	longtext	NULL,
	`cf_privacy`	longtext	NULL,
	`cf_noemail`	longtext	NULL,
	`cf_tel`	varchar(255)	NULL,
	`cf_zip`	int(11)	NULL,
	`cf_addr`	varchar(255)	NULL,
	`cf_addr2`	varchar(255)	NULL,
	`cf_fax`	varchar(50)	NULL,
	`cf_email`	varchar(255)	NULL,
	`cf_owner_name`	varchar(255)	NULL,
	`cf_day_point`	int(11)	NULL,
	`cf_check_use`	tinyint(4)	NULL,
	`cf_od_point`	int(11)	NULL,
	`cf_percent`	int(11)	NULL
);

CREATE TABLE `order` (
	`od_id`	varchar(255)	NOT NULL,
	`od_name`	varchar(255)	NULL,
	`mb_id`	varchar(255)	NULL,
	`od_price`	int(11)	NULL,
	`od_point`	int(11)	NULL	,
	`od_date`	DATETIME	NULL,
	`od_status`	varchar(50)	NULL,
	`od_st_code`	varchar(255)	NULL,
	`od_st_name`	varchar(255)	NULL,
	`od_qty`	int(11)	NULL,
	`od_st_price`	int(11)	NULL,
	`od_percent_price`	int(11)	NULL
);

CREATE TABLE `stock` (
	`st_code`	varchar(255)	NOT NULL,
	`st_name`	varchar(255)	NULL,
	`st_qty`	int(11)	NULL,
	`st_board_cnt`	int(11)	NULL,
	`st_category`	varchar(255)	NULL,
	`st_status`	varchar(255)	NULL
);

CREATE TABLE `board` (
	`wr_no`	INT(11) AUTO_INCREMENT	NOT NULL,
	`wr_category`	varchar(255)	NULL,
	`wr_content`	text	NULL,
	`mb_id`	varchar(255)	NULL,
	`wr_comment`	int(11)	NULL	DEFAULT 0,
	`wr_good`	int(11)	NULL	DEFAULT 0,
	`wr_singo`	int(11)	NULL	DEFAULT 0,
	`wr_blind`	char(2)	NULL	DEFAULT N
);

CREATE TABLE `stock_info` (
	`si_id`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`si_date`	date	NULL,
	`si_price`	int(11)	NULL,
	`st_code`	varchar(255)	NOT NULL
);

CREATE TABLE `comment` (
	`co_id`	INT(11) AUTO_INCREMENT	NOT NULL,
	`wr_no`	INT(11) AUTO_INCREMENT	NOT NULL,
	`co_good`	int(11)	NULL,
	`co_content`	text	NULL,
	`mb_id`	varchar(255)	NULL
);

CREATE TABLE `wish_stock` (
	`wi_id`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`st_code`	varchar(255)	NOT NULL,
	`mb_id`	varchar(255)	NULL
);

CREATE TABLE `news_emoji` (
	`em_no`	INT(11) AUTO_INCREMENT	NOT NULL,
	`ne_no`	INT(11) AUTO_INCREMENT	NOT NULL,
	`em_act`	int(11)	NULL	COMMENT '1 기뻐요
2 화나요
3 황당해요
4 슬퍼요',
	`mb_id`	varchar(255)	NULL,
	`em_datetime`	DATETIME	NULL
);

CREATE TABLE `news` (
	`ne_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`np_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`ne_title`	varchar(255)	NULL,
	`ne_content`	longtext	NULL,
	`mb_id`	varchar(255)	NULL,
	`ne_datetime`	DATETIME	NULL,
	`ne_edit_date`	DATETIME	NULL,
	`ne_name`	varchar(255)	NULL,
	`ne_happy`	int(11)	NULL,
	`ne_angry`	int(11)	NULL,
	`ne_absurd`	int(11)	NULL,
	`ne_sad`	int(11)	NULL
);

CREATE TABLE `member_lv` (
	`lv_name`	varchar(255)	NULL,
	`lv_num`	int(11)	NULL,
	`lv_alpha`	varchar(255)	NULL,
	`lv_auto_use`	char(2)	NULL	DEFAULT N	COMMENT 'Y/N 판별',
	`lv_up_limit`	int(11)	NULL	DEFAULT 0
);

CREATE TABLE `point` (
	`po_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`po_num`	int(11)	NULL,
	`po_content`	varchar(255)	NULL,
	`po_datetime`	DATETIME	NULL,
	`po_end_date`	int(11)	NULL,
	`mb_id`	varchar(255)	NULL
);

CREATE TABLE `follow` (
	`fo_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`mb_id`	varchar(255)	NULL,
	`fo_mb_id`	varchar(255)	NULL
);

CREATE TABLE `event` (
	`ev_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`ev_title`	varchar(255)	NULL,
	`ev_content`	longtext	NULL,
	`ev_start_level`	int(11)	NULL,
	`ev_end_level`	int(11)	NULL,
	`ev_point`	int(11)	NULL,
	`ev_datetime`	DATETIME	NULL,
	`ev_start`	DATETIME	NULL,
	`ev_end`	DATETIME	NULL,
	`ev_status`	char(2)	NULL,
	`ev_cnt`	int(11)	NULL
);

CREATE TABLE `event_list` (
	`el_no`	INT(11) AUTO_INCREMENT	NOT NULL,
	`ev_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`mb_id`	varchar(255)	NULL,
	`el_datetime`	DATETIME	NULL
);

CREATE TABLE `day_check` (
	`출석 기본키`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`출석체크일`	DATETIME	NULL,
	`출석체크 회원 아이디`	varchar(255)	NULL,
	`지급된 출석 체크 포인트`	int(11)	NULL
);

CREATE TABLE `stock_add` (
	`sa_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`sa_qty`	int(11)	NULL,
	`mb_id`	varchar(255)	NULL,
	`sa_datetime`	DATETIME	NULL,
	`sa_yn`	char(2)	NULL,
	`sa_content`	text	NULL,
	`sa_feedback`	text	NULL
);

CREATE TABLE `newspaper` (
	`np_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`np_name`	varchar(255)	NULL,
	`np_use`	tinyint(4)	NULL
);

CREATE TABLE `file` (
	`fi_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`fi_org_name`	varchar(255)	NULL,
	`fi_path`	text	NULL,
	`fi_num`	int(11)	NULL,
	`fi_reg_no`	int(11)	NULL,
	`fi_type`	varchar(255)	NULL
);

CREATE TABLE `event_prize` (
	`ep_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`ev_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`ep_prize`	varchar(255)	NULL,
	`ep_mb_id`	varchar(255)	NULL,
	`ep_rank`	int(11)	NULL
);

CREATE TABLE `stock_member` (
	`mb_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`mb_stock`	varchar(255)	NULL
);

CREATE TABLE `news_member` (
	`mb_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`mb_news`	varchar(255)	NULL
);

CREATE TABLE `deposit_order` (
	`do_od_id`	varchar(255)	NOT NULL,
	`do_name`	varchar(255)	NULL,
	`mb_id`	varchar(255)	NULL,
	`do_price`	int(11)	NULL,
	`do_tno`	varchar(255)	NULL,
	`do_auth`	varchar(255)	NULL,
	`do_date`	DATETIME	NULL,
	`do_status`	varchar(50)	NULL
);

CREATE TABLE `deposit` (
	`de_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`de_content`	varchar(255)	NULL,
	`de_datetime`	DATETIME	NULL,
	`de_stock_code`	varchar(255)	NULL,
	`mb_id`	varchar(255)	NULL
);

CREATE TABLE `account` (
	`mb_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`ac_deposit`	int(11)	NULL
);

CREATE TABLE `reservation` (
	`re_no`	INT(11)  AUTO_INCREMENT	NOT NULL,
	`re_datetime`	DATETIME	NULL,
	`mb_id`	varchar(255)	NULL,
	`re_want_price`	int(11)	NULL,
	`re_st_code`	varchar(255)	NULL,
	`re_qty`	int(11)	NULL,
	`re_state`	varchar(255)	NULL
);

CREATE TABLE `member_approve` (
	`mp_no`	int(11)  AUTO_INCREMENT	NOT NULL,
	`mp_type`	varchar(50)	NULL,
	`mp_yn`	char(4)	NULL,
	`mp_company`	varchar(255)	NULL,
	`mp_datetime`	DATETIME	NULL,
	`mp_app_date`	DATETIME	NULL,
	`mb_no`	INT(11)  AUTO_INCREMENT	NOT NULL
);

ALTER TABLE `member` ADD CONSTRAINT `PK_MEMBER` PRIMARY KEY (
	`mb_no`
);

ALTER TABLE `order` ADD CONSTRAINT `PK_ORDER` PRIMARY KEY (
	`od_id`
);

ALTER TABLE `stock` ADD CONSTRAINT `PK_STOCK` PRIMARY KEY (
	`st_code`
);

ALTER TABLE `board` ADD CONSTRAINT `PK_BOARD` PRIMARY KEY (
	`wr_no`
);

ALTER TABLE `stock_info` ADD CONSTRAINT `PK_STOCK_INFO` PRIMARY KEY (
	`si_id`
);

ALTER TABLE `comment` ADD CONSTRAINT `PK_COMMENT` PRIMARY KEY (
	`co_id`
);

ALTER TABLE `wish_stock` ADD CONSTRAINT `PK_WISH_STOCK` PRIMARY KEY (
	`wi_id`
);

ALTER TABLE `news_emoji` ADD CONSTRAINT `PK_NEWS_EMOJI` PRIMARY KEY (
	`em_no`
);

ALTER TABLE `news` ADD CONSTRAINT `PK_NEWS` PRIMARY KEY (
	`ne_no`
);

ALTER TABLE `point` ADD CONSTRAINT `PK_POINT` PRIMARY KEY (
	`po_no`
);

ALTER TABLE `follow` ADD CONSTRAINT `PK_FOLLOW` PRIMARY KEY (
	`fo_no`
);

ALTER TABLE `event` ADD CONSTRAINT `PK_EVENT` PRIMARY KEY (
	`ev_no`
);

ALTER TABLE `event_list` ADD CONSTRAINT `PK_EVENT_LIST` PRIMARY KEY (
	`el_no`
);

ALTER TABLE `day_check` ADD CONSTRAINT `PK_DAY_CHECK` PRIMARY KEY (
	`출석 기본키`
);

ALTER TABLE `stock_add` ADD CONSTRAINT `PK_STOCK_ADD` PRIMARY KEY (
	`sa_no`
);

ALTER TABLE `newspaper` ADD CONSTRAINT `PK_NEWSPAPER` PRIMARY KEY (
	`np_no`
);

ALTER TABLE `file` ADD CONSTRAINT `PK_FILE` PRIMARY KEY (
	`fi_no`
);

ALTER TABLE `event_prize` ADD CONSTRAINT `PK_EVENT_PRIZE` PRIMARY KEY (
	`ep_no`
);

ALTER TABLE `stock_member` ADD CONSTRAINT `PK_STOCK_MEMBER` PRIMARY KEY (
	`mb_no`
);

ALTER TABLE `news_member` ADD CONSTRAINT `PK_NEWS_MEMBER` PRIMARY KEY (
	`mb_no`
);

ALTER TABLE `deposit_order` ADD CONSTRAINT `PK_DEPOSIT_ORDER` PRIMARY KEY (
	`do_od_id`
);

ALTER TABLE `deposit` ADD CONSTRAINT `PK_DEPOSIT` PRIMARY KEY (
	`de_no`
);

ALTER TABLE `account` ADD CONSTRAINT `PK_ACCOUNT` PRIMARY KEY (
	`mb_no`
);

ALTER TABLE `reservation` ADD CONSTRAINT `PK_RESERVATION` PRIMARY KEY (
	`re_no`
);

ALTER TABLE `member_approve` ADD CONSTRAINT `PK_MEMBER_APPROVE` PRIMARY KEY (
	`mp_no`
);

ALTER TABLE `stock_member` ADD CONSTRAINT `FK_member_TO_stock_member_1` FOREIGN KEY (
	`mb_no`
)
REFERENCES `member` (
	`mb_no`
);

ALTER TABLE `news_member` ADD CONSTRAINT `FK_member_TO_news_member_1` FOREIGN KEY (
	`mb_no`
)
REFERENCES `member` (
	`mb_no`
);

ALTER TABLE `account` ADD CONSTRAINT `FK_member_TO_account_1` FOREIGN KEY (
	`mb_no`
)
REFERENCES `member` (
	`mb_no`
);

