package kh.st.boot.dao;

public interface admOrderPageDAO {

}
