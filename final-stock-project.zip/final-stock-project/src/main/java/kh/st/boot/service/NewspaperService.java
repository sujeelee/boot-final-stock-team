package kh.st.boot.service;

public interface newspaperService {

}
